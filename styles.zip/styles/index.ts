import { Colors } from './theme/colors';
import { Spacing } from './theme/spacing';
import { Typography } from './theme/typography';

// 布局样式
import { layoutStyles } from './layouts/layout';
import { tabStyles } from './layouts/tab';
import { parallaxStyles, HEADER_HEIGHT } from './layouts/parallax';
import { errorStyles } from './layouts/error';

// 基础组件
import { textStyles } from './components/base/text';
import { buttonStyles } from './components/base/button';
import { cardStyles } from './components/base/card';
import { formStyles } from './components/base/form';

// 业务组件
import { transactionStyles } from './components/finance/transaction';
import { budgetStyles } from './components/finance/budget';
import { debugStyles } from './components/settings/debug';

// 统一导出的样式结构
import { getNavigationTheme, screenOptions } from './theme/navigation';
import { uiStyles } from './components/ui';
import { collapsibleStyles } from './layouts/collapsible';

export const styles = {
  // 主题
  colors: Colors,
  spacing: Spacing,
  typography: Typography,

  // 布局
  layout: {
    ...layoutStyles,
    error: errorStyles,
    collapsible: collapsibleStyles,
    parallax: {
      ...parallaxStyles,
      headerHeight: HEADER_HEIGHT,
    },
  },
  tab: tabStyles,

  // 基础组件
  text: textStyles,
  button: buttonStyles,
  card: cardStyles,
  form: formStyles,

  // 业务组件
  finance: {
    transaction: transactionStyles,
    budget: budgetStyles,
  },
  settings: {
    debug: debugStyles,
  },
  ui: uiStyles,
  navigation: {
    getTheme: getNavigationTheme,
    screenOptions,
  },
} as const;

// 为了向后兼容，也导出这些常量
export { Colors, Spacing, Typography };