import { StyleSheet } from 'react-native';
import { Colors } from '../theme/colors';
import { Spacing } from '../theme/spacing';

export const uiStyles = StyleSheet.create({
  link: {
    color: Colors.primary,
  },
  tabBar: {
    backgroundColor: Colors.card,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  icon: {
    alignItems: 'center',
    justifyContent: 'center',
  },
}); 