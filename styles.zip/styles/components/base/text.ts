import { StyleSheet } from 'react-native';
import { Colors } from '../../theme/colors';
import { Typography } from '../../theme/typography';

export const textStyles = StyleSheet.create({
  base: {
    ...Typography.body,
    color: Colors.text,
  },
  title: {
    ...Typography.title,
    color: Colors.text,
  },
  subtitle: {
    ...Typography.subtitle,
    color: Colors.text,
  },
  caption: {
    ...Typography.caption,
    color: Colors.textSecondary,
  },
  link: {
    ...Typography.body,
    color: Colors.primary,
  },
});