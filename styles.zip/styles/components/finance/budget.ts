import { StyleSheet } from 'react-native';
import { Colors } from '../../theme/colors';
import { Spacing } from '../../theme/spacing';
import { Typography } from '../../theme/typography';

export const budgetStyles = StyleSheet.create({
  // BudgetItem styles
  item: {
    padding: Spacing.md,
    backgroundColor: Colors.card,
    borderRadius: 8,
    marginBottom: Spacing.sm,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  name: {
    ...Typography.subtitle,
    color: Colors.text,
  },
  amount: {
    ...Typography.subtitle,
    color: Colors.text,
  },
  info: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  category: {
    ...Typography.body,
    color: Colors.textSecondary,
  },
  period: {
    ...Typography.body,
    color: Colors.textSecondary,
  },
  
  // BudgetList styles
  list: {
    flex: 1,
    padding: Spacing.md,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: Spacing.md,
  },
  
  // BudgetSelector styles
  selector: {
    flex: 1,
  },
  selectorItem: {
    padding: Spacing.sm,
    backgroundColor: Colors.background,
    borderRadius: 8,
    width: '49%',
    marginBottom: Spacing.xs,
  },
}); 