import { StyleSheet } from 'react-native';
import { Colors } from '../../theme/colors';
import { Spacing } from '../../theme/spacing';
import { Typography } from '../../theme/typography';

export const transactionStyles = StyleSheet.create({
  // TransactionItem styles
  item: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: Spacing.md,
    borderRadius: 8,
    marginHorizontal: Spacing.md,
    marginVertical: Spacing.sm,
    backgroundColor: Colors.card,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 3,
  },
  leftContent: {
    flex: 1,
  },
  description: {
    ...Typography.body,
    fontWeight: '500',
    marginBottom: Spacing.xs,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Spacing.xs,
  },
  
  // TransactionList styles
  list: {
    flex: 1,
  },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: Spacing.lg,
  },
  
  // TransactionForm styles
  form: {
    flex: 1,
  },
  typeSelector: {
    flexDirection: 'row',
    backgroundColor: Colors.background,
    borderRadius: 8,
    padding: Spacing.xs,
  },
  typeButton: {
    flex: 1,
    padding: Spacing.sm,
    alignItems: 'center',
    borderRadius: 6,
  },
  activeTypeButton: {
    backgroundColor: Colors.primary,
  },
  typeButtonText: {
    ...Typography.body,
    color: Colors.text,
  },
  activeTypeButtonText: {
    color: Colors.card,
  },
  currency: {
    fontSize: 18,
    marginRight: Spacing.sm,
    color: Colors.text,
  },
  amountInput: {
    flex: 1,
  },
  descriptionInput: {
    height: 100,
    textAlignVertical: 'top',
  },
}); 