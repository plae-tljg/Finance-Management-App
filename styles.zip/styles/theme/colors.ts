import { ColorSchemeName } from 'react-native';

export const Colors = {
  // 主色
  primary: '#007AFF',
  
  // 文本颜色
  text: '#000000',
  textSecondary: '#666666',
  
  // 背景颜色
  background: '#f8f8f8',
  card: '#ffffff',
  border: '#e0e0e0',
  
  // 状态颜色
  success: '#4CAF50',
  error: '#F44336',
  warning: '#FFC107',
} as const;

export type ThemeColors = typeof Colors;

export function getThemeColors(scheme: ColorSchemeName): ThemeColors {
  return scheme === 'dark' ? Colors as ThemeColors : Colors;
}