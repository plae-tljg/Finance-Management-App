import { DarkTheme, DefaultTheme } from '@react-navigation/native';
import { Colors } from './colors';
import { Platform } from 'react-native';

export function getNavigationTheme(colorScheme: 'light' | 'dark') {
  return {
    ...(colorScheme === 'dark' ? DarkTheme : DefaultTheme),
    colors: {
      ...(colorScheme === 'dark' ? DarkTheme.colors : DefaultTheme.colors),
      background: Colors.background,
      card: Colors.card,
      text: Colors.text,
      border: Colors.border,
    },
  };
}

export const screenOptions = {
  headerStyle: {
    backgroundColor: Colors.background,
  },
  headerTintColor: Colors.text,
  headerTitleStyle: {
    fontWeight: 'bold',
  },
  contentStyle: {
    backgroundColor: Colors.background,
  },
} as const;

export const tabScreenOptions = {
  tabBarActiveTintColor: Colors.primary,
  tabBarInactiveTintColor: Colors.textSecondary,
  headerShown: false,
  tabBarBackground: () => null,
  tabBarStyle: {
    backgroundColor: Colors.card,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    elevation: 8,
    shadowOpacity: 0.1,
    shadowRadius: 4,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: -2,
    },
    height: Platform.OS === 'ios' ? 88 : 60,
    paddingBottom: Platform.OS === 'ios' ? 28 : 8,
  },
};

export const tabScreens = {
  home: {
    title: '首页',
    icon: 'home',
  },
  add: {
    title: '添加',
    icon: 'add-circle',
  },
  settings: {
    title: '设置',
    icon: 'settings',
  },
} as const; 