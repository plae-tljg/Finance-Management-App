import { StyleSheet } from 'react-native';
import { Colors } from '../theme/colors';
import { Spacing } from '../theme/spacing';

export const layoutStyles = StyleSheet.create({
  // 容器相关
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  content: {
    flex: 1,
    padding: Spacing.md,
  },
  header: {
    padding: Spacing.md,
  },
  
  // Flex 布局
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  spaceBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  center: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  wrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },

  // 其他布局工具类
  gap: {
    gap: Spacing.sm,
  },
  padding: {
    padding: Spacing.md,
  },
  margin: {
    margin: Spacing.md,
  },
}); 