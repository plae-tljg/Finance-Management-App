import { StyleSheet } from 'react-native';
import { Spacing } from '../theme/spacing';

export const HEADER_HEIGHT = 250;

export const parallaxStyles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    height: HEADER_HEIGHT,
    overflow: 'hidden',
  },
  content: {
    flex: 1,
    padding: Spacing.xl,
    gap: Spacing.md,
    overflow: 'hidden',
  },
}); 