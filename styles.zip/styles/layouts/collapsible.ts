import { StyleSheet } from 'react-native';
import { Spacing } from '../theme/spacing';

export const collapsibleStyles = StyleSheet.create({
  heading: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  content: {
    marginTop: Spacing.xs,
    marginLeft: Spacing.xl,
  },
}); 